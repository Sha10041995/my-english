# LinguaQuest AI — MVP prototype

Responsive, dependency-free HTML/CSS/JavaScript prototype for an Uzbek-first gamified English learning app targeting CEFR B2.

## Run
- Open `index.html` in a modern browser, or serve the folder with any static server.
- Example: `python -m http.server 8080` and visit `http://localhost:8080`.

## Included demo flows
- Dashboard with XP, streak, active vocabulary and skill progress
- Navigation across Speaking, Reading, Writing, Listening, vocabulary, progress and diagnostic pages
- Diagnostic placement quiz (5 sample questions; indicative only, not an official CEFR assessment)
- Speaking response review (rule-based demo) and browser SpeechRecognition when available
- Reading and listening comprehension checks
- Browser speech synthesis for the listening script when supported
- Writing feedback with basic heuristic suggestions
- Vocabulary practice and mission completion XP
- Responsive layout for desktop and mobile

## Production architecture recommendation
- Frontend: Next.js + TypeScript, responsive PWA
- API: Next.js route handlers or a separate FastAPI/Node service
- Auth/database: Supabase Auth + PostgreSQL
- AI: server-side LLM API for feedback and adaptive content; realtime speech or separate STT/TTS services
- Assessment: rubric-based skill scoring calibrated against CEFR descriptors, with human/external validation
- Vocabulary: store encounters, context, recall confidence, and independent use; only count as active after evidence of productive use

## Important limitations
This is a local interactive prototype. It does not include account login, a backend, durable cloud sync, a real LLM, calibrated CEFR scoring, or production speech assessment. Demo metrics and feedback are illustrative. Never expose API keys in browser code; call AI providers from a server-side endpoint.
